//Classe
class Carro {
    construtor(marca, modelo, ano, cor) {
    //atributo (propriedades da classe)
    this.marca = marca;
    this.modelo = modelo;
    this.ano = ano;
    this.cor = cor;
    
    }
}